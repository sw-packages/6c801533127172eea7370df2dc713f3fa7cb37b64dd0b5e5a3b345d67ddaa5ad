This subdir originated as a best-effort C approximation of the C++ code in
in third_party/protobuf/io/ but over time the two will invariably diverge.
Comments have generally been copied verbatim and may therefore refer to C++
symbol names instead of C symbol names.
